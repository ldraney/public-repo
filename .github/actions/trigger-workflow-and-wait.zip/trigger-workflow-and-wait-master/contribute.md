# Contribute

```shell
docker build . -t trigger-workflow-and-wait
```
